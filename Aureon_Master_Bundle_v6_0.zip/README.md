# Aureon IX — Master Bundle v6.0

This repository layout is designed for the `ymgholdings/Aureon` project and for direct integration with a Custom GPT called **AUREON IX**.

## Structure

- `codex/`
  - `Aureon_Codex_v5.1.md` — Operational specification for the Aureon Transform Framework (ATF), modes, invariants, Research Mode protocol, and diagnostic tests.

- `math/`
  - `Aureon_Transform_Expanded_Proofs.tex` — Full operator-theoretic paper with Lipschitz bounds, fixed-point theorem, evolution stability, and RQML convergence.
  - `Aureon_Transform_Developer_Notes.tex` — Lean implementation-oriented summary of ATF math.

- `config/`
  - `aureon_config_manifest_v1_0.json` — Machine-readable configuration manifest for Aureon parameters (operators, RQML, Research Mode safety rules).

- `tests/`
  - `Aureon_Test_Suite.md` — General behavioral test prompts for Aureon IX.
  - `aureon_research_test_harness_v1_0.md` — Research-Mode Test Harness (RMT) for probing RQML stability, self-refinement boundaries, and hallucination resistance.

- `system/`
  - `Aureon_System_Instructions.txt` — System prompt text to paste into the Custom GPT “Instructions” field.

- `docs/`
  - `logo_math_binding_notes.md` — Documentation of how the Aureon logo is interpreted as a symbolic math glyph and how it binds to ATF operators.

## Using This With a Custom GPT

1. Create a new Custom GPT named **AUREON IX**.
2. Paste the contents of `system/Aureon_System_Instructions.txt` into the GPT’s Instructions.
3. Upload as Knowledge at least:
   - `codex/Aureon_Codex_v5.1.md`
   - `math/Aureon_Transform_Expanded_Proofs.tex`
   - `math/Aureon_Transform_Developer_Notes.tex`
   - `config/aureon_config_manifest_v1_0.json`
   - `docs/logo_math_binding_notes.md`
4. Use prompts from `tests/Aureon_Test_Suite.md` and `tests/aureon_research_test_harness_v1_0.md` to validate stability, Research Mode behavior, and hallucination resistance.

## Suggested GitHub Usage

Place this folder at the root of your repository:

- Repo: `ymgholdings/Aureon`
- Root contents: this structure as-is.

Commit and push:

```bash
git add .
git commit -m "Add Aureon IX Master Bundle v6.0"
git push origin main
```

From there, you can iterate on math, Codex, or config while preserving a stable, versioned baseline.
