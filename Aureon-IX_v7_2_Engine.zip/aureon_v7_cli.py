
from aureon_v7.interfaces.cli_driver import main

if __name__ == "__main__":
    main()
