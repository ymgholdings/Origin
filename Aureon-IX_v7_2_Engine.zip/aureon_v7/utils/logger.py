
import datetime

def log_event(event: str, metadata: dict | None = None):
    """Lightweight logger. In production, route to proper logging."""
    ts = datetime.datetime.utcnow().isoformat() + "Z"
    # For now, just return the record; in a real system we'd write to a log sink.
    return {"timestamp": ts, "event": event, "metadata": metadata or {}}
