
import math

def _safe_as_vector(x):
    """Convert a value into a flat list of floats if possible, else []"""
    if x is None:
        return []
    if isinstance(x, (int, float)):
        return [float(x)]
    if isinstance(x, str):
        # try to split comma-separated
        parts = [p.strip() for p in x.split(",")]
        out = []
        for p in parts:
            try:
                out.append(float(p))
            except Exception:
                try:
                    out.append(abs(complex(p)))
                except Exception:
                    continue
        return out
    if isinstance(x, (list, tuple)):
        out = []
        for v in x:
            try:
                out.append(float(v))
            except Exception:
                try:
                    out.append(abs(complex(v)))
                except Exception:
                    continue
        return out
    return []

def _l2_norm_diff(a, b):
    va = _safe_as_vector(a)
    vb = _safe_as_vector(b)
    if not va and not vb:
        return 0.0
    # pad shorter
    n = max(len(va), len(vb))
    va += [0.0] * (n - len(va))
    vb += [0.0] * (n - len(vb))
    return math.sqrt(sum((va[i] - vb[i])**2 for i in range(n)))

def compute_structural_delta(Dn: dict, Dn1: dict,
                             weights=(0.4, 0.3, 0.3)):
    """Composite structural distance between successive datasets."""
    wm, wc, wq = weights
    gm = _l2_norm_diff(Dn.get("metric_tensor"), Dn1.get("metric_tensor"))
    cp = _l2_norm_diff(Dn.get("causal_operator"), Dn1.get("causal_operator"))
    qs = _l2_norm_diff(Dn.get("quantum_state"), Dn1.get("quantum_state"))
    return wm * gm + wc * cp + wq * qs

def _entropy_from_state(state):
    """Approximate von Neumann entropy via probabilities from amplitudes."""
    vec = _safe_as_vector(state)
    if not vec:
        return 0.0
    # normalize to probabilities
    norm = sum(v**2 for v in vec) or 1.0
    probs = [v**2 / norm for v in vec]
    entropy = 0.0
    for p in probs:
        if p > 0:
            entropy -= p * math.log(p, 2.0)
    return entropy

def compute_entropy_delta(Dn: dict, Dn1: dict):
    """Difference in approximate entropy between successive quantum states."""
    s0 = _entropy_from_state(Dn.get("quantum_state"))
    s1 = _entropy_from_state(Dn1.get("quantum_state"))
    return s1 - s0
