
from ..utils.logger import log_event

class QuantumLayer:
    """Quantum-inspired layer that normalizes a simple complex state vector."""

    def evolve_state(self, state_str: str):
        """state_str: comma-separated list of complex-like strings, e.g. '1+0j,0+0j'"""
        parts = [s.strip() for s in state_str.split(",")]
        coeffs = []
        for p in parts:
            try:
                coeffs.append(complex(p))
            except Exception:
                coeffs.append(0+0j)
        norm_sq = sum(abs(c)**2 for c in coeffs) or 1.0
        norm = norm_sq**0.5
        normalized = [c / norm for c in coeffs]
        result = [str(c) for c in normalized]
        log_event("QuantumLayer.evolve_state", metadata={"input": state_str, "output": result})
        return result
