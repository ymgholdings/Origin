
from .rqml_loop import RQMLLoop
from ..utils.logger import log_event
from ..utils.metrics import compute_structural_delta, compute_entropy_delta

class RQMLSupervisor:
    """
    Supervisory controller for adaptive multi-step RQML recursion.
    Monitors convergence via structural and entropy-based metrics.
    """

    def __init__(self, max_steps: int = 10, epsilon: float = 1e-3, stable_window: int = 2):
        self.max_steps = max_steps
        self.epsilon = epsilon
        self.stable_window = stable_window
        # use single-step loop; supervisor manages overall depth
        self.loop = RQMLLoop(max_steps=1)
        self.history = []
        self.convergence_counter = 0

    def run(self, seed_dataset: dict):
        """Execute adaptive RQML refinement until convergence or max_steps reached."""
        current = dict(seed_dataset)
        log_event("RQMLSupervisor start", metadata={"epsilon": self.epsilon, "stable_window": self.stable_window})

        for step in range(1, self.max_steps + 1):
            archive = self.loop.run_cycle(current)
            latest_entry = archive[-1] if isinstance(archive, list) and archive else archive
            latest = latest_entry.get("dataset") if isinstance(latest_entry, dict) and "dataset" in latest_entry else latest_entry

            if self.history:
                prev = self.history[-1]
                struct_delta = compute_structural_delta(prev, latest)
                entropy_delta = compute_entropy_delta(prev, latest)
                combined_delta = struct_delta + 0.2 * abs(entropy_delta)

                log_event("RQMLSupervisor step", metadata={
                    "step": step,
                    "struct_delta": struct_delta,
                    "entropy_delta": entropy_delta,
                    "combined_delta": combined_delta,
                })

                if combined_delta < self.epsilon:
                    self.convergence_counter += 1
                    if self.convergence_counter >= self.stable_window:
                        log_event("Convergence achieved", metadata={
                            "step": step,
                            "combined_delta": combined_delta,
                            "struct_delta": struct_delta,
                            "entropy_delta": entropy_delta,
                        })
                        self.history.append(latest)
                        return latest
                else:
                    self.convergence_counter = 0
            else:
                log_event("RQMLSupervisor first step", metadata={"step": step})

            self.history.append(latest)
            current = latest

        log_event("Supervisor terminated: max steps reached", metadata={"steps": self.max_steps})
        return self.history[-1] if self.history else current

    def get_history(self):
        """Return all intermediate datasets for analysis."""
        return list(self.history)
