
from .rqml_loop import RQMLLoop
from .rqml_supervisor import RQMLSupervisor
from .causal_engine import CausalEngine
from .quantum_layer import QuantumLayer
from .ontology_engine import OntologyEngine
from .dataset_store import DatasetStore

class AureonCore:
    """High-level orchestrator that exposes Aureon v7 tasks."""

    def __init__(self, max_steps: int = 3):
        self.rqml_loop = RQMLLoop(max_steps=max_steps)
        self.supervisor = RQMLSupervisor(max_steps=max_steps)
        self.causal = CausalEngine()
        self.quantum = QuantumLayer()
        self.ontology = OntologyEngine()

    def run(self, task: str, payload: str | None = None):
        """Dispatch tasks by name. Payload is a simple string or None."""
        if task == "rqml":
            seed = {
                "raw": payload or "seed",
                "math_structure": "...",
                "physical_hypothesis": "...",
                "quantum_state": "1+0j,0+0j"
            }
            return {"archive": self.rqml_loop.run_cycle(seed)}
        if task == "rqml_supervised":
            seed = {
                "raw": payload or "seed",
                "math_structure": "...",
                "physical_hypothesis": "...",
                "quantum_state": "1+0j,0+0j"
            }
            result = self.supervisor.run(seed)
            return {"converged_dataset": result, "history": self.supervisor.get_history()}
        if task == "causal_step":
            return self.causal.step({"state": payload or "seed"})
        if task == "quantum_sim":
            return self.quantum.evolve_state(payload or "1+0j,0+0j")
        if task == "ontology_audit":
            return self.ontology.audit({"model": payload or "seed"})
        raise ValueError(f"Unknown task: {task}")
