
class DatasetStore:
    """In-memory dataset archive with simple versioning."""

    def __init__(self):
        self._archive = []

    def commit(self, dataset: dict, label: str | None = None):
        entry = {"label": label, "dataset": dataset}
        self._archive.append(entry)

    def archive(self):
        return list(self._archive)

    def __len__(self):
        return len(self._archive)
