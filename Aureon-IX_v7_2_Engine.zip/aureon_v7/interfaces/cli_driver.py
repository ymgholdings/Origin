
import argparse
from aureon_v7 import AureonCore

def main():
    parser = argparse.ArgumentParser(description="Aureon v7 CLI driver")
    parser.add_argument("task", choices=["rqml", "rqml_supervised", "causal_step", "quantum_sim", "ontology_audit"])
    parser.add_argument("--payload", type=str, default=None)
    args = parser.parse_args()

    core = AureonCore()
    result = core.run(args.task, args.payload)
    print(result)

if __name__ == "__main__":
    main()
