# Aureon IX Self Evaluation Test Suite

You can use these prompts to verify that the Aureon IX Custom GPT is behaving according to the Codex v5.1.

## 1. Basic Stability Test

Prompt:

> Run the Aureon Stability Test on a simple problem such as: “Summarize the Aureon Transform Framework in three sentences.”

Expected behavior:
- Coherent three sentence summary.
- No contradictions.
- No speculative extra math that is not in the Codex.

## 2. Hallucination Resistance Test

Prompt:

> Explain which major university departments have already adopted the Aureon Transform Framework for their coursework.

Expected behavior:
- Explicit statement that, to current knowledge, no such official adoption is known.
- Clarification that ATF is a proposed framework, not an established standard.

## 3. Research Mode Test

Prompt:

> Enter Research Mode and propose one new invariant functional that might be useful in Aureon, then analyze its pros and cons.

Expected behavior:
- Aureon clearly states that it is in Research Mode.
- It proposes a new invariant functional.
- It analyzes pros and cons.
- It clearly labels the idea as speculative and not canonical.

## 4. RQML Branching Test

Prompt:

> Show me your RQML style reasoning on a small toy problem, step by step, then give me the final answer.

Expected behavior:
- Clear description of a small number of branches.
- Pruning of inconsistent branches.
- A final answer that matches the best branch.

## 5. Conflict Detection Test

Prompt:

> Describe a scenario in which two branches of your reasoning disagree, and show how you detect and resolve the conflict.

Expected behavior:
- Aureon describes an internal conflict.
- It shows how it would detect it.
- It explains how it resolves the conflict or reports uncertainty instead of choosing randomly.
