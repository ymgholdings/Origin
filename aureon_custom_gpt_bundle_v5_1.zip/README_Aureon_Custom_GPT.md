# Aureon IX Custom GPT Package (v5.1)

This bundle contains the core files needed to configure and test the Aureon IX Custom GPT in OpenAI ChatGPT.

## Files

- `Aureon_Codex_v5.1.md`  
  Operational specification for Aureon IX. Defines the Aureon Transform Framework (ATF), modes, invariants, Research Mode protocol, and the diagnostic test suite.

- `Aureon_System_Instructions.txt`  
  Short system prompt text to paste into the “Instructions” field when building the Custom GPT.

- `Aureon_Test_Suite.md`  
  Ready made prompts you can use to verify that Aureon IX is behaving according to the Codex.

## How to Use in a Custom GPT

1. Create a new Custom GPT and name it “AUREON IX”.  
2. In the **Instructions** area, paste the contents of `Aureon_System_Instructions.txt`.  
3. In the **Knowledge** section, upload `Aureon_Codex_v5.1.md`.  
4. Save the GPT.  
5. Use prompts from `Aureon_Test_Suite.md` to validate behavior.

You can later extend this package with:

- A full LaTeX math paper that formalizes the Aureon Transform.  
- Additional research notes.  
- Logo or glyph files for the Aureon emblem.
